package com.lynxian.syzaria.mod.proxy;

public class CommonProxy {
	
	public void preInit(){
		
	}
	
	public void Init(){
		
	}
	
	public void postInit(){
		
	}
}
