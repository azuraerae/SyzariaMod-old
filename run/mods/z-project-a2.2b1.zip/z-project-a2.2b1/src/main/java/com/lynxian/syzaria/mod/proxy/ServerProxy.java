package com.lynxian.syzaria.mod.proxy;

public class ServerProxy extends CommonProxy{
	
	@Override
	public void preInit() {
		super.preInit();
	}
	
	@Override
	public void Init() {
		super.Init();
	}
	
	@Override
	public void postInit() {
		super.postInit();
	}
	
}
