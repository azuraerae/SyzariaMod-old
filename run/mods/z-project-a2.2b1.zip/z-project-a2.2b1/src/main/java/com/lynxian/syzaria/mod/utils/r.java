package com.lynxian.syzaria.mod.utils;

public class r {
    public static final String MODID = "syzaria";
    public static final String NAME = "Syzaria";
    public static final String VERSION = "a2.0";
    
    public static final String cProxy = "com.lynxian.syzaria.mod.proxy.ClientProxy";
    public static final String sProxy = "com.lynxian.syzaria.mod.proxy.ServerProxy";

}
