package com.lynxian.syzaria.mod;

import static com.lynxian.syzaria.mod.utils.r.MODID;
import static com.lynxian.syzaria.mod.utils.r.NAME;
import static com.lynxian.syzaria.mod.utils.r.VERSION;
import static com.lynxian.syzaria.mod.utils.r.cProxy;
import static com.lynxian.syzaria.mod.utils.r.sProxy;

import com.lynxian.syzaria.mod.init.Blocks;
import com.lynxian.syzaria.mod.init.Items;
import com.lynxian.syzaria.mod.init.Recipes;
import com.lynxian.syzaria.mod.init.CTabs.CBlocks;
import com.lynxian.syzaria.mod.init.CTabs.CFight;
import com.lynxian.syzaria.mod.init.CTabs.CItems;
import com.lynxian.syzaria.mod.init.CTabs.CMisc;
import com.lynxian.syzaria.mod.init.CTabs.CTools;
import com.lynxian.syzaria.mod.proxy.CommonProxy;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = MODID, name = NAME, version = VERSION, useMetadata = true)
public class main {

	@Mod.Instance(MODID)
	public static main instance; 

	public static CreativeTabs CItems = new CItems("syza_items_tab");
	public static CreativeTabs CBlocks = new CBlocks("syza_blocks_tab");
	public static CreativeTabs CFight = new CFight("syza_fight_tab");
	public static CreativeTabs CTools = new CTools("syza_tools_tab");
	public static CreativeTabs CMisc = new CMisc("syza_misc_tab");
	
	@SidedProxy(clientSide = cProxy, serverSide = sProxy)
	public static CommonProxy proxy; 
	
	public main() {
		Blocks.init();
		Items.init();
		Recipes.init();
	}
	
	@EventHandler
	public void preInit(FMLPreInitializationEvent e) {
		proxy.preInit();
	}
	
	@EventHandler
	public void Init(FMLInitializationEvent e) {
		proxy.Init();
	}
	
	@EventHandler
	public void postInit(FMLPostInitializationEvent e) {
		proxy.postInit();
	}

}

