package com.lynxian.syzaria.mod.init.CTabs;

import com.lynxian.syzaria.mod.init.Items;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;

public class CFight extends CreativeTabs{
    public CFight(String name) {
        super(name);
    }

    @Override
    public ItemStack getTabIconItem() {
        return new ItemStack(Items.tungstene_sword);
    }
    
}
