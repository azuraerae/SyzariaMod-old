package com.lynxian.syzaria.mod.init;

public class Recipes {
    public static void init() {
        
    }
}
