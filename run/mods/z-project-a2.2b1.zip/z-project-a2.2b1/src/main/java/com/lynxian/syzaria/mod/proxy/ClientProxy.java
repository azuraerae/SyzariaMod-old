package com.lynxian.syzaria.mod.proxy;

public class ClientProxy extends CommonProxy{
	
	@Override
	public void preInit() {
		super.preInit();
	}
	
	@Override
	public void Init() {
		super.Init();
	}
	
	@Override
	public void postInit() {
		super.postInit();
	}
	
}
